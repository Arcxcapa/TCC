<?php
require_once __DIR__ . '/../arquivos/session.php';
require_once __DIR__ . '/../arquivos/conexao.php';

// Verificar autenticação
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login/login.php', true, 302);
    exit;
}

// Buscar usuário
$stmt = $pdo->prepare("SELECT id, nome, email, role FROM usuarios WHERE id = :id LIMIT 1");
$stmt->execute([':id' => $_SESSION['usuario_id']]);
$usuario = $stmt->fetch();

if (!$usuario) {
    session_destroy();
    header('Location: ../login/login.php', true, 302);
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script src="https://cdn.tailwindcss.com"></script>

    <title>Dashboard — EducaTEC</title>
</head>

<body class="bg-gray-50 text-gray-800 overflow-hidden">

<!-- BOTÃO MOBILE -->
<button
id="menuBtn"
class="md:hidden fixed top-4 left-4a z-30 bg-blue-600 text-white w-12 h-12 rounded-full shadow-lg text-2xl flex items-center justify-center">
    ⋮
</button>

<div class="flex h-screen">

    <!-- OVERLAY -->
    <div
    id="overlay"
    class="fixed inset-0 bg-black/50 z-30 hidden md:hidden">
    </div>

    <!-- SIDEBAR -->
    <aside
    id="sidebar"
    class="fixed md:fixed top-0 left-0 z-40 w-64 bg-white border-r border-gray-200 h-screen overflow-y-auto
    transform -translate-x-full md:translate-x-0 transition-transform duration-300 ease-in-out">

        <!-- LOGO -->
        <div class="h-20 flex items-center px-6 border-b border-gray-200">

            <a
            href="../index.html"
            class="text-2xl font-black tracking-tighter text-gray-900 flex items-center gap-1">

                Educa<span class="text-blue-500">TEC</span>

            </a>

        </div>

        <!-- MENU -->
        <nav class="p-4 space-y-2">

            <a
            href="dashboard.php"
            class="flex items-center gap-3 px-4 py-3 rounded-lg bg-blue-50 text-blue-600 font-semibold">

                Início

            </a>

            <a
            href="#"
            class="flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-all">

                Matérias

            </a>

            <a
            href="#"
            class="flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-all">

                Respostas

            </a>

            <a
            href="#"
            class="flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-all">

                Histórico

            </a>

            <a
            href="#"
            class="flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-all">

                Configurações

            </a>

            <hr class="my-4 border-gray-200">

            <a
            href="../login/logout.php"
            class="flex items-center gap-3 px-4 py-3 rounded-lg text-red-600 hover:bg-red-50 transition-all font-semibold">

                Sair

            </a>

        </nav>

        <!-- PERFIL -->
        <div class="border-t border-gray-200 p-4 mt-auto">

            <div class="flex items-center gap-3">

                <div class="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">

                    <?php echo strtoupper(substr($usuario['nome'], 0, 1)); ?>

                </div>

                <div class="flex-1 min-w-0">

                    <p class="text-sm font-bold text-gray-900 truncate">

                        <?php echo htmlspecialchars($usuario['nome'], ENT_QUOTES, 'UTF-8'); ?>

                    </p>

                    <p class="text-xs text-gray-500 capitalize">

                        <?php echo htmlspecialchars($usuario['role'] ?? 'aluno', ENT_QUOTES, 'UTF-8'); ?>

                    </p>

                </div>

            </div>

        </div>

    </aside>

    <!-- MAIN -->
    <div class="flex-1 flex flex-col h-screen md:ml-64">

        <!-- NAVBAR -->
        <nav
        class="bg-white border-b border-gray-200 h-20 flex items-center justify-between px-6">

            <!-- BUSCA -->
            <div class="relative w-full max-w-md ml-16 md:ml-0">

                <input
                type="text"
                id="searchInput"
                placeholder="Buscar..."
                class="w-full h-12 px-5 rounded-full bg-gray-100 outline-none focus:ring-2 focus:ring-blue-400">

                <svg
                class="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24">

                    <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z">
                    </path>

                </svg>

            </div>

        </nav>

        <!-- CONTEÚDO -->
        <main class="flex-1 overflow-y-auto p-8">

            <!-- HEADER -->
            <div class="mb-10">

                <h1 class="text-4xl font-black text-gray-900 mb-2">

                    Bem-vindo!

                </h1>

                <p class="text-gray-500">

                    Explore exercícios, aulas e muito mais

                </p>

            </div>

            <!-- FILTROS -->
            <div class="mb-8 flex flex-wrap gap-2">

                <button class="px-4 py-2 rounded-full bg-blue-500 text-white font-semibold">
                    Todos
                </button>

                <button class="px-4 py-2 rounded-full bg-white border border-gray-200">
                    Exercícios
                </button>

                <button class="px-4 py-2 rounded-full bg-white border border-gray-200">
                    Aulas
                </button>

                <button class="px-4 py-2 rounded-full bg-white border border-gray-200">
                    Tópicos
                </button>

            </div>

            <!-- GRID -->
            <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">

                <!-- CARD -->
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-lg transition-all">

                    <div class="flex items-center justify-between mb-4">

                        <div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                            📘
                        </div>

                        <span class="text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded-full font-semibold">
                            Exercício
                        </span>

                    </div>

                    <h3 class="text-lg font-bold text-gray-900 mb-2">
                        Exercícios de Matemática
                    </h3>

                    <p class="text-sm text-gray-600 mb-4">
                        Resolva questões e pratique conteúdos importantes.
                    </p>

                    <div class="flex items-center justify-between text-xs text-gray-500">

                        <span>10 questões</span>

                        <span class="text-blue-600 font-semibold">
                            Iniciar →
                        </span>

                    </div>

                </div>

                <!-- CARD -->
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-lg transition-all">

                    <div class="flex items-center justify-between mb-4">

                        <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                            🎥
                        </div>

                        <span class="text-xs bg-green-100 text-green-700 px-3 py-1 rounded-full font-semibold">
                            Aula
                        </span>

                    </div>

                    <h3 class="text-lg font-bold text-gray-900 mb-2">
                        Aula de Física
                    </h3>

                    <p class="text-sm text-gray-600 mb-4">
                        Aprenda conceitos fundamentais de circuitos elétricos.
                    </p>

                    <div class="flex items-center justify-between text-xs text-gray-500">

                        <span>45 minutos</span>

                        <span class="text-green-600 font-semibold">
                            Assistir →
                        </span>

                    </div>

                </div>

                <!-- CARD -->
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-lg transition-all">

                    <div class="flex items-center justify-between mb-4">

                        <div class="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                            🚀
                        </div>

                        <span class="text-xs bg-purple-100 text-purple-700 px-3 py-1 rounded-full font-semibold">
                            Tópico
                        </span>

                    </div>

                    <h3 class="text-lg font-bold text-gray-900 mb-2">
                        Plano de Estudos
                    </h3>

                    <p class="text-sm text-gray-600 mb-4">
                        Organize seus estudos em 14 dias.
                    </p>

                    <div class="flex items-center justify-between text-xs text-gray-500">

                        <span>14 dias</span>

                        <span class="text-purple-600 font-semibold">
                            Explorar →
                        </span>

                    </div>

                </div>

            </div>

        </main>

    </div>

</div>

<!-- SCRIPT MENU -->
<script>

const menuBtn = document.getElementById('menuBtn');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

menuBtn.addEventListener('click', () => {

    sidebar.classList.toggle('-translate-x-full');
    overlay.classList.toggle('hidden');

});

overlay.addEventListener('click', () => {

    sidebar.classList.add('-translate-x-full');
    overlay.classList.add('hidden');

});

</script>

</body>
</html>

<?php
require_once __DIR__ . '/../arquivos/session.php';
require_once __DIR__ . '/../arquivos/conexao.php';

// Verificar autenticação
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login/login.php', true, 302);
    exit;
}

// Buscar usuário
$stmt = $pdo->prepare("SELECT id, nome, email, role FROM usuarios WHERE id = :id LIMIT 1");
$stmt->execute([':id' => $_SESSION['usuario_id']]);
$usuario = $stmt->fetch();

if (!$usuario) {
    session_destroy();
    header('Location: ../login/login.php', true, 302);
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Dashboard — EducaTEC</title>
</head>

<body class="bg-gray-50 text-gray-800 overflow-hidden">

<!-- BOTÃO MOBILE -->
<button
id="menuBtn"
class="md:hidden fixed top-4 left-4 z-50 bg-blue-600 text-white w-12 h-12 rounded-full shadow-lg text-2xl flex items-center justify-center">
    ⋮
</button>

<div class="flex h-screen">

    <!-- OVERLAY -->
    <div
    id="overlay"
    class="fixed inset-0 bg-black/50 z-30 hidden md:hidden">
    </div>

    <!-- SIDEBAR -->
    <aside
    id="sidebar"
    class="fixed md:fixed top-0 left-0 z-40 w-64 bg-white border-r border-gray-200 h-screen overflow-y-auto
    transform -translate-x-full md:translate-x-0 transition-transform duration-300 ease-in-out">

        <!-- LOGO -->
        <div class="h-20 flex items-center px-6 border-b border-gray-200">

            <a
            href="../index.html"
            class="text-2xl font-black tracking-tighter text-gray-900 flex items-center gap-1">

                Educa<span class="text-blue-500">TEC</span>

            </a>

        </div>

        <!-- MENU -->
        <nav class="p-4 space-y-2">

            <button
            class="menu-link w-full text-left flex items-center gap-3 px-4 py-3 rounded-lg bg-blue-50 text-blue-600 font-semibold"
            data-section="inicio">

                Início

            </button>

            <button
            class="menu-link w-full text-left flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-all"
            data-section="materias">

                Matérias

            </button>

            <button
            class="menu-link w-full text-left flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-all"
            data-section="respostas">

                Respostas

            </button>

            <button
            class="menu-link w-full text-left flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-all"
            data-section="historico">

                Histórico

            </button>

            <button
            class="menu-link w-full text-left flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-all"
            data-section="configuracoes">

                Configurações

            </button>

            <hr class="my-4 border-gray-200">

            <a
            href="../login/logout.php"
            class="flex items-center gap-3 px-4 py-3 rounded-lg text-red-600 hover:bg-red-50 transition-all font-semibold">

                Sair

            </a>

        </nav>

        <!-- PERFIL -->
        <div class="border-t border-gray-200 p-4 mt-auto">

            <div class="flex items-center gap-3">

                <div class="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">

                    <?php echo strtoupper(substr($usuario['nome'], 0, 1)); ?>

                </div>

                <div class="flex-1 min-w-0">

                    <p class="text-sm font-bold text-gray-900 truncate">

                        <?php echo htmlspecialchars($usuario['nome'], ENT_QUOTES, 'UTF-8'); ?>

                    </p>

                    <p class="text-xs text-gray-500 capitalize">

                        <?php echo htmlspecialchars($usuario['role'] ?? 'aluno', ENT_QUOTES, 'UTF-8'); ?>

                    </p>

                </div>

            </div>

        </div>

    </aside>

    <!-- MAIN -->
    <div class="flex-1 flex flex-col h-screen md:ml-64">

        <!-- NAVBAR -->
        <nav
        class="bg-white border-b border-gray-200 h-20 flex items-center justify-between px-6">

            <!-- BUSCA -->
            <div class="relative w-full max-w-md ml-16 md:ml-0">

                <input
                type="text"
                id="searchInput"
                placeholder="Buscar..."
                class="w-full h-12 px-5 rounded-full bg-gray-100 outline-none focus:ring-2 focus:ring-blue-400">

                <svg
                class="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24">

                    <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z">
                    </path>

                </svg>

            </div>

        </nav>

        <!-- CONTEÚDO -->
        <main class="flex-1 overflow-y-auto p-8">

            <!-- INÍCIO -->
            <section id="inicio" class="content-section">

                <!-- HEADER -->
                <div class="mb-10">

                    <h1 class="text-4xl font-black text-gray-900 mb-2">

                        Bem-vindo!

                    </h1>

                    <p class="text-gray-500">

                        Explore exercícios, aulas e muito mais

                    </p>

                </div>

                <!-- FILTROS -->
                <div class="mb-8 flex flex-wrap gap-2">

                    <button class="filter-btn px-4 py-2 rounded-full bg-blue-500 text-white font-semibold"
                    data-filter="all">
                        Todos
                    </button>

                    <button class="filter-btn px-4 py-2 rounded-full bg-white border border-gray-200"
                    data-filter="exercicios">
                        Exercícios
                    </button>

                    <button class="filter-btn px-4 py-2 rounded-full bg-white border border-gray-200"
                    data-filter="aulas">
                        Aulas
                    </button>

                    <button class="filter-btn px-4 py-2 rounded-full bg-white border border-gray-200"
                    data-filter="topicos">
                        Tópicos
                    </button>

                </div>

                <!-- CARDS GRID -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="cardsContainer">

                    <!-- CARD 1 -->
                    <div class="card bg-white rounded-2xl shadow-sm hover:shadow-lg transition-all p-6 border border-gray-100 cursor-pointer hover:border-blue-300"
                    data-filter="exercicios">

                        <div class="flex items-start justify-between mb-4">

                            <div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">

                                <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">

                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>

                                </svg>

                            </div>

                            <span class="text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded-full font-semibold">
                                Exercício
                            </span>

                        </div>

                        <h3 class="text-lg font-bold text-gray-900 mb-2">
                            Exercícios sobre sequência numérica com padrão
                        </h3>

                        <p class="text-sm text-gray-600 mb-4">
                            As sequências numéricas são conceitos matemáticos essenciais. Neste exercício...
                        </p>

                        <div class="flex items-center justify-between text-xs text-gray-500">

                            <span>10 questões</span>

                            <span class="text-blue-600 font-semibold">
                                Iniciar →
                            </span>

                        </div>

                    </div>

                    <!-- CARD 2 -->
                    <div class="card bg-white rounded-2xl shadow-sm hover:shadow-lg transition-all p-6 border border-gray-100 cursor-pointer hover:border-orange-300"
                    data-filter="exercicios">

                        <div class="flex items-start justify-between mb-4">

                            <div class="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">

                                <svg class="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">

                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path>

                                </svg>

                            </div>

                            <span class="text-xs bg-orange-100 text-orange-700 px-3 py-1 rounded-full font-semibold">
                                Exercício
                            </span>

                        </div>

                        <h3 class="text-lg font-bold text-gray-900 mb-2">
                            Exercícios sobre relações métricas no triângulo retângulo
                        </h3>

                        <p class="text-sm text-gray-600 mb-4">
                            Estes exercícios sobre relações métricas no triângulo...
                        </p>

                        <div class="flex items-center justify-between text-xs text-gray-500">

                            <span>8 questões</span>

                            <span class="text-orange-600 font-semibold">
                                Iniciar →
                            </span>

                        </div>

                    </div>

                    <!-- CARD 3 -->
                    <div class="card bg-white rounded-2xl shadow-sm hover:shadow-lg transition-all p-6 border border-gray-100 cursor-pointer hover:border-green-300"
                    data-filter="aulas">

                        <div class="flex items-start justify-between mb-4">

                            <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">

                                <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">

                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 6.253v13m0-13C6.228 6.228 2 10.228 2 15s4.228 8.772 10 8.772 10-4.228 10-8.772c0-4.772-4.228-8.747-10-8.747z"></path>

                                </svg>

                            </div>

                            <span class="text-xs bg-green-100 text-green-700 px-3 py-1 rounded-full font-semibold">
                                Aula
                            </span>

                        </div>

                        <h3 class="text-lg font-bold text-gray-900 mb-2">
                            Integração de Carga e Análise em Circuitos
                        </h3>

                        <p class="text-sm text-gray-600 mb-4">
                            A tecnologia em uma sociedade em aceleração frequente...
                        </p>

                        <div class="flex items-center justify-between text-xs text-gray-500">

                            <span>45 min</span>

                            <span class="text-green-600 font-semibold">
                                Assistir →
                            </span>

                        </div>

                    </div>

                    <!-- CARD 4 -->
                    <div class="card bg-white rounded-2xl shadow-sm hover:shadow-lg transition-all p-6 border border-gray-100 cursor-pointer hover:border-purple-300"
                    data-filter="topicos">

                        <div class="flex items-start justify-between mb-4">

                            <div class="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">

                                <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">

                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M13 10V3L4 14h7v7l9-11h-7z"></path>

                                </svg>

                            </div>

                            <span class="text-xs bg-purple-100 text-purple-700 px-3 py-1 rounded-full font-semibold">
                                Tópico
                            </span>

                        </div>

                        <h3 class="text-lg font-bold text-gray-900 mb-2">
                            14 dias de estudo para avançar em Física
                        </h3>

                        <p class="text-sm text-gray-600 mb-4">
                            Qual é o propósito de um plano de estudos...
                        </p>

                        <div class="flex items-center justify-between text-xs text-gray-500">

                            <span>14 dias</span>

                            <span class="text-purple-600 font-semibold">
                                Começar →
                            </span>

                        </div>

                    </div>

                    <!-- CARD 5 -->
                    <div class="card bg-white rounded-2xl shadow-sm hover:shadow-lg transition-all p-6 border border-gray-100 cursor-pointer hover:border-red-300"
                    data-filter="exercicios">

                        <div class="flex items-start justify-between mb-4">

                            <div class="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">

                                <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">

                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 12l2 2 4-4m7 0a9 9 0 11-18 0 9 9 0 0118 0z"></path>

                                </svg>

                            </div>

                            <span class="text-xs bg-red-100 text-red-700 px-3 py-1 rounded-full font-semibold">
                                Exercício
                            </span>

                        </div>

                        <h3 class="text-lg font-bold text-gray-900 mb-2">
                            Exercícios sobre literatura de cord
                        </h3>

                        <p class="text-sm text-gray-600 mb-4">
                            Comentários sobre a
                        </p>

                        <div class="flex items-center justify-between text-xs text-gray-500">

                            <span>12 questões</span>

                            <span class="text-red-600 font-semibold">
                                Iniciar →
                            </span>

                        </div>

                    </div>

                    <!-- CARD 6 -->
                    <div class="card bg-white rounded-2xl shadow-sm hover:shadow-lg transition-all p-6 border border-gray-100 cursor-pointer hover:border-cyan-300"
                    data-filter="topicos">

                        <div class="flex items-start justify-between mb-4">

                            <div class="w-12 h-12 bg-cyan-100 rounded-xl flex items-center justify-center">

                                <svg class="w-6 h-6 text-cyan-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">

                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M12 6.253v13m0-13C6.228 6.228 2 10.228 2 15s4.228 8.772 10 8.772 10-4.228 10-8.772c0-4.772-4.228-8.747-10-8.747z"></path>

                                </svg>

                            </div>

                            <span class="text-xs bg-cyan-100 text-cyan-700 px-3 py-1 rounded-full font-semibold">
                                Tópico
                            </span>

                        </div>
                        <h3 class="text-lg font-bold text-gray-900 mb-2">
                            Mais círculo de Linguagens, Códigos e suas Metodologias
                        </h3>
                        <p class="text-sm text-gray-600 mb-4">
                            Neste círculo, você encontrará uma nova perspective...
                        </p>
                        <div class="flex items-center justify-between text-xs text-gray-500">
                            <span>8 módulos</span>
                            <span class="text-cyan-600 font-semibold">
                                Explorar →
                            </span>
                        </div>
                    </div>
                </div>
            </section>

            <!-- MATÉRIAS -->
            <section id="materias" class="content-section hidden">
                <h1 class="text-4xl font-black text-gray-900 mb-4">
                    Matérias
                </h1>
            </section>

            <!-- RESPOSTAS -->
            <section id="respostas" class="content-section hidden">
                <h1 class="text-4xl font-black text-gray-900 mb-4">
                    Respostas
                </h1>
            </section>

            <!-- HISTÓRICO -->
            <section id="historico" class="content-section hidden">
                <h1 class="text-4xl font-black text-gray-900 mb-4">
                    Histórico
                </h1>
            </section>

            <!-- CONFIGURAÇÕES -->
            <section id="configuracoes" class="content-section hidden">
                <h1 class="text-4xl font-black text-gray-900 mb-4">
                    Configurações
                </h1>
            </section>
        </main>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {

    // MENU MOBILE
    const menuBtn = document.getElementById('menuBtn');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    menuBtn.addEventListener('click', () => {
        sidebar.classList.toggle('-translate-x-full');
        overlay.classList.toggle('hidden');
    });
    overlay.addEventListener('click', () => {

        sidebar.classList.add('-translate-x-full');
        overlay.classList.add('hidden');

    });

    // MENU LATERAL
    const menuLinks = document.querySelectorAll('.menu-link');
    const sections = document.querySelectorAll('.content-section');
    menuLinks.forEach(link => {
        link.addEventListener('click', () => {
            const target = link.dataset.section;
            // RESET BOTÕES
            menuLinks.forEach(btn => {

                btn.classList.remove(
                    'bg-blue-50',
                    'text-blue-600',
                    'font-semibold'
                );
                btn.classList.add('text-gray-700');
            });
            // BOTÃO ATIVO
            link.classList.add(
                'bg-blue-50',
                'text-blue-600',
                'font-semibold'
            );
            // ESCONDER SEÇÕES
            sections.forEach(section => {
                section.classList.add('hidden');
            });
            // MOSTRAR SEÇÃO
            document.getElementById(target).classList.remove('hidden');
            // FECHAR MOBILE
            sidebar.classList.add('-translate-x-full');
            overlay.classList.add('hidden');
        });
    });
    // FILTROS
    const filterButtons = document.querySelectorAll('.filter-btn');
    const cards = document.querySelectorAll('.card');
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            const filter = button.dataset.filter;
            // RESET BOTÕES
            filterButtons.forEach(btn => {
                btn.classList.remove('bg-blue-500', 'text-white');
                btn.classList.add(
                    'bg-white',
                    'border',
                    'border-gray-200'
                );
            });
            // BOTÃO ATIVO
            button.classList.remove(
                'bg-white',
                'border',
                'border-gray-200'
            );
            button.classList.add(
                'bg-blue-500',
                'text-white'
            );
            // FILTRAGEM
            cards.forEach(card => {
                const category = card.dataset.filter;
                if (filter === 'all' || category === filter) {
                    card.classList.remove('hidden');
                } else {
                    card.classList.add('hidden');
                }
            });
        });
    });
});
</script>
</body>
</html>
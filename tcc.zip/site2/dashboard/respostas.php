<?php
require_once __DIR__ . '/../arquivos/session.php';
require_once __DIR__ . '/../arquivos/conexao.php';

if(!isset($_SESSION['usuario_id'])){
    header('Location: ../login/login.php');
    exit;
}

$stmt=$pdo->prepare("SELECT id,nome,email,role FROM usuarios WHERE id=:id LIMIT 1");
$stmt->execute([':id'=>$_SESSION['usuario_id']]);
$usuario=$stmt->fetch();

if(!$usuario){
    session_destroy();
    header('Location: ../login/login.php');
    exit;
}

$sql=$pdo->prepare("
SELECT 
p.titulo,
p.materias,
r.resposta_escolhida,
r.acertou,
r.created_at,
e.nota
FROM respostas_alunos r
INNER JOIN postagens p ON r.postagem_id=p.id
LEFT JOIN entregas_alunos e 
ON e.aluno_id=r.aluno_id AND e.postagem_id=p.id
WHERE r.aluno_id=:aluno
ORDER BY r.created_at DESC
");

$sql->execute([':aluno'=>$_SESSION['usuario_id']]);
$respostas=$sql->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
<title>Respostas - EducaTEC</title>
</head>

<body class="bg-gray-50 text-gray-800">

<div class="flex h-screen">

<aside class="w-64 bg-white border-r hidden md:flex flex-col">

<div class="h-20 flex items-center px-6 border-b">
<a href="dashboard.php" class="text-2xl font-black">
📚 Educa<span class="text-blue-600">TEC</span>
</a>
</div>

<nav class="p-4 space-y-2 flex-1">
<a href="dashboard.php" class="block px-4 py-3 rounded-lg hover:bg-blue-50">🏠 Início</a>
<a href="materias.php" class="block px-4 py-3 rounded-lg hover:bg-blue-50">📖 Matérias</a>
<a href="respostas.php" class="block px-4 py-3 rounded-lg bg-blue-50 text-blue-600 font-semibold">💬 Respostas</a>
<a href="historico.php" class="block px-4 py-3 rounded-lg hover:bg-blue-50">🕒 Histórico</a>
<a href="configuracoes.php" class="block px-4 py-3 rounded-lg hover:bg-blue-50">⚙ Configurações</a>
<hr>
<a href="../login/logout.php" class="block px-4 py-3 rounded-lg text-red-600 hover:bg-red-50">🚪 Sair</a>
</nav>

<div class="border-t p-4">
<div class="flex items-center gap-3">
<div class="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold">
<?= strtoupper(substr($usuario['nome'],0,1)); ?>
</div>

<div>
<p class="font-bold text-sm"><?= htmlspecialchars($usuario['nome']); ?></p>
<p class="text-xs text-gray-500"><?= htmlspecialchars($usuario['role']); ?></p>
</div>
</div>
</div>

</aside>


<div class="flex-1 flex flex-col">

<header class="h-20 bg-white border-b flex items-center justify-between px-6">
<h2 class="text-xl font-bold">Respostas</h2>

<div class="w-10 h-10 bg-blue-600 rounded-full text-white flex items-center justify-center font-bold">
<?= strtoupper(substr($usuario['nome'],0,1)); ?>
</div>
</header>


<main class="p-8 overflow-y-auto">

<h1 class="text-4xl font-black mb-2">Minhas Respostas</h1>

<p class="text-gray-500 mb-8">
Confira suas atividades respondidas.
</p>


<div class="bg-white rounded-2xl border shadow-sm overflow-hidden">

<table class="w-full">

<thead class="bg-blue-600 text-white">

<tr>
<th class="p-4 text-left">Matéria</th>
<th class="p-4 text-left">Atividade</th>
<th class="p-4">Resposta</th>
<th class="p-4">Resultado</th>
<th class="p-4">Nota</th>
<th class="p-4">Data</th>
</tr>

</thead>

<tbody>

<?php foreach($respostas as $resposta): ?>

<tr class="border-b hover:bg-gray-50">

<td class="p-4"><?= htmlspecialchars($resposta['materias']); ?></td>

<td class="p-4"><?= htmlspecialchars($resposta['titulo']); ?></td>

<td class="p-4"><?= htmlspecialchars($resposta['resposta_escolhida']); ?></td>

<td class="p-4 text-center">

<?= $resposta['acertou']
? '<span class="bg-green-100 text-green-700 px-3 py-1 rounded-full">Correta</span>'
: '<span class="bg-red-100 text-red-700 px-3 py-1 rounded-full">Errada</span>'; ?>

</td>

<td class="p-4 text-center">
<?= $resposta['nota'] ?? 0; ?>
</td>

<td class="p-4">
<?= date('d/m/Y',strtotime($resposta['created_at'])); ?>
</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</main>

</div>

</div>

</body>
</html>